﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication17
{
    class Boligrafo
    {

        public const short cantidadTintaMaxima=100;
        private ConsoleColor _color;
        private short _tinta;

        public Boligrafo(ConsoleColor color,short tinta) 
        {
            this.SetTinta(tinta);
            this._color = color;
        }

        public ConsoleColor GetColor() 
        {
            return this._color;
        }
        public short GetTinta()
        { 
            return this._tinta;
        }
        private void SetTinta(short tinta)
        {
            if (this._tinta<100 && this._tinta>0)
            {
                this._tinta = tinta;
            }
        
        }
        public void Recargar()
        {
            this.SetTinta(100);
        }

        public bool Pintar(int gasto, out string dibujo) 
        {
            if (this._tinta < gasto)
            {
                this._tinta = 0;
            }
            else
                this._tinta -= (short)gasto;


            return true;
        }


    }
}
