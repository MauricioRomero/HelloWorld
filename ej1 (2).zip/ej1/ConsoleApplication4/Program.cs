﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int num=1;
            for (int i = 0; i < num; i++)
            {
                if (num%i==0)
                {
                    sum = sum + i;
                }

                num++;
            }
        }
    }
}
