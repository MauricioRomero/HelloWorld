﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{
    class Alumno
    {
        private Byte _nota1;
        private Byte _nota2;
        private float _notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        Alumno() { }

        public Alumno(string nombre, string apellido, int legajo) :base()
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.legajo = legajo;
        
        }

        public void CalcularFinal() {
            Random r=new Random(this.legajo);
            if (this._nota1 < 4 || this._nota2 < 4)
            {
                this._notaFinal = -1;
            }
            else
            {
                this._notaFinal =r.Next(4,10);        
                
            }

        
        }

        public void Estudiar(byte notaUno, byte notaDos) {

            this._nota1 = notaUno;
            this._nota2 = notaDos;
        }


        public void Mostrar() {

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Nombre: "+this.nombre);
            sb.AppendLine("Apellido: "+this.apellido);
            sb.AppendLine("Legajo: "+this.legajo);
            sb.AppendLine("Nota final: ");
            if (this._notaFinal == -1)
            {
                sb.AppendLine("Alumno Desaprobado");
            }
            else
                sb.AppendLine("" + this._notaFinal);

            Console.WriteLine(sb.ToString());
        }
    
    }
}
