﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno a1 = new Alumno("Marina", "Cerillano", 1);
            Alumno a2 = new Alumno("Leia", "Cerillano", 2);
            Alumno a3 = new Alumno("Luke", "Romero", 5);

            a1.Estudiar(5,9);
            a2.Estudiar(3,2);
            a3.Estudiar(10, 4);

            a1.CalcularFinal();
            a2.CalcularFinal();
            a3.CalcularFinal();

            a1.Mostrar();
            a2.Mostrar();
            a3.Mostrar();

            Console.ReadKey();
        }
    }
}
