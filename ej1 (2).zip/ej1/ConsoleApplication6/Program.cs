﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            int c=0, max=0, min=99999, num, cont=0;
            float prom;
            do
            {
                Console.WriteLine("Ingrese numero: ");
                num = int.Parse(Console.ReadLine());
                if (num<min)
                {
                    min = num;
                }
                if (num>max)
                {
                    max = num;
                }
                cont = cont + num;
                c++;
            } while (c<5);
            prom = cont / c;
            Console.WriteLine("El maximo es: {0}", max);
            Console.WriteLine("El minimo es: {0}", min);
            Console.WriteLine("El promedio es: {0}", prom);
            Console.ReadKey();
        }
    }
}
