﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num=-1;
            do
            {
                
                Console.WriteLine("Ingresar un numero > 0: ");
                num = int.Parse(Console.ReadLine());
                if (num<0)
                {
                    Console.WriteLine("Error reingresar numero.");
                }
            } while (num<0);
           Console.WriteLine("cuadrado: "+Math.Pow(num, 2));
           Console.WriteLine("cubo: " + Math.Pow(num, 3));
           Console.ReadKey();

        }
    }
}
