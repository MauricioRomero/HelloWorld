﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            bool t = true;
            Console.WriteLine("Ingrese numero");
            num=int.Parse(Console.ReadLine());
            for (int i = 2; i < num; i++)
            {
                if (num%i==0)
                {
                    Console.WriteLine("el numero no es primo!");
                    t = false;
                    break;
                }
            }
            if (t)
            {
                Console.WriteLine("El numero es primo");
            }
            Console.ReadKey();
        }
    }
}
