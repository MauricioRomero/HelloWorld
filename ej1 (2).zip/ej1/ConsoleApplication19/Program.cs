﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication19
{
    class Program
    {
        static void Main(string[] args)
        {
            Sumador s = new Sumador();
            Sumador s2 = new Sumador();
            
            Console.WriteLine(s.Sumar("Hola", "S 2"));
            Console.WriteLine( s.Sumar("Hola", "Pibe"));
            Console.WriteLine(  s2.Sumar(2, 2));
            Console.WriteLine(s.Sumar(3, 2));
            Console.WriteLine(s.Sumar(6, 2));

            Console.WriteLine(s2.Sumar(2, 2));

            Console.WriteLine((int)s);
            Console.WriteLine(s | s2);
            Console.WriteLine(s+s2);
            
            Console.ReadKey();
        }
    }
}
