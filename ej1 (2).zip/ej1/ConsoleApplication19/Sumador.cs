﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication19
{
    class Sumador
    {
        private int _cantidadSumas;

        public Sumador(int cantidadSumas)
        {
            this._cantidadSumas = cantidadSumas;
        
        }
        public Sumador()
        {
            Sumador s = new Sumador(0);
            this._cantidadSumas = s._cantidadSumas;
        }

        public long Sumar(long a, long b)
        {
            this._cantidadSumas = this._cantidadSumas+1;
            return a + b;
        }

        public String Sumar(String a, String b)
        {
            this._cantidadSumas =this._cantidadSumas +1;
            return a+b;
        }

        public static explicit operator int(Sumador s)
        {
            return s._cantidadSumas;


        }

        public static bool operator | (Sumador s1,Sumador s2)
        {
            return s2._cantidadSumas == s1._cantidadSumas;
        }

        public static long operator  +(Sumador s1, Sumador s2)
        {
            return s1._cantidadSumas + s2._cantidadSumas;
        }

        
    }
}
